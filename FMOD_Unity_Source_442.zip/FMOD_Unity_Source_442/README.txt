SquareTangle FMOD plugin for Unity.
version 04.03.12
Using FMOD 4.42
http://squaretangle.com
04/03/12

Hi All,

This plugin allows FMOD http://www.fmod.org/ to be used from within the Unity game development environment http://unity3d.com/
You may use this plugin in your own projects free of charge in accordance with the MIT license.
See the LICENSE.txt file for details of the license.
Please see the FMOD fmod.org and Unity unity3d.com licenses separately for details on their usage in your projects.

FMODUnity.dll has been tested with Unity 3.4.2 on both Mac and Windows.
It works with the low level FMOD_Ex as well as the FMOD_Event systems.
It won't work with IOS or web player.

USAGE
Place FMODUnity.dll in your Assets/Plugins folder
Place fmodex.dll, fmod_event.dll, libfmodex.dylib and libfmod_event.dylib in the root folder of your Unity project.

If you have downloaded the FMOD_Unity_Demo.zip example unity project look at the FMOD_Ex_Test.unity or FMOD_Event_Test.unity scenes.
Example Unity c# scripts for both the Ex and Event system are in the Assets/FMOD folder.
The examples are translations of the playsound and simple_event examples from the FMOD API.

For more details and future updates go to http://squaretangle.com and look for the FMOD plugin project.
This is a largely untested update made quickly for anyone who might be interested.

We hope you find this plugin useful and enjoyable.

04/01/2012
As many would know, with FMOD becoming native to Unity the older version of this plugin broke ;-(
There were some workarounds and alternatives.
A great thread was this one:
http://www.fmod.org/forum/viewtopic.php?p=46744
We decided to see what functionality would be incorporated into unity's FMOD implementation before spending more time on this plugin. We also were busy with other projects and there were solutions offered by others.
But we still get requests for help, and the native implementation doesn't support the FMOD Event system, so we have tried to update the wrapper to the latest version and have noted that the main naming conflict seems to have gone. Hopefully this may be of use to some.

All the best

adam square
johnny tangle