//FMOD for Unity plugin. copyright 2009 squaretangle. MIT License
//Please redistribute any modifications or enhancements
//squaretangle.com for details

using System;
using System.Collections.Generic;
using System.Text;

namespace FMOD
{
    public class EventCallback
    {
       //TO DO, maybe add a callback function for use with unsafe code 
        //Unity doesn't support unsafe code blocks
    }
}
